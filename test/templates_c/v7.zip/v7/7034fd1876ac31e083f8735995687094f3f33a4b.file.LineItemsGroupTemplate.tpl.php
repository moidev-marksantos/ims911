<?php /* Smarty version Smarty-3.1.7, created on 2020-12-09 05:03:37
         compiled from "C:\xampp\htdocs\nuevaviscaya\includes\runtime/../../layouts/v7\modules\Settings\Workflows\LineItemsGroupTemplate.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2338413395fd05aa9b16095-57363413%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7034fd1876ac31e083f8735995687094f3f33a4b' => 
    array (
      0 => 'C:\\xampp\\htdocs\\nuevaviscaya\\includes\\runtime/../../layouts/v7\\modules\\Settings\\Workflows\\LineItemsGroupTemplate.tpl',
      1 => 1602587794,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2338413395fd05aa9b16095-57363413',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5fd05aa9b5457',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5fd05aa9b5457')) {function content_5fd05aa9b5457($_smarty_tpl) {?>



<DIV>TEMPLATE: layout/modules/Settings/Workflows/LineItemsGroupTemplate.tpl</DIV>
<?php }} ?>