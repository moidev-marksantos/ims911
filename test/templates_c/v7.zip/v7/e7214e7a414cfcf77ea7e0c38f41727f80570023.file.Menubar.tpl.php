<?php /* Smarty version Smarty-3.1.7, created on 2020-12-09 04:19:27
         compiled from "C:\xampp\htdocs\nuevaviscaya\includes\runtime/../../layouts/v7\modules\Events\partials\Menubar.tpl" */ ?>
<?php /*%%SmartyHeaderCode:7544673125fd0504f6fc708-78569424%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e7214e7a414cfcf77ea7e0c38f41727f80570023' => 
    array (
      0 => 'C:\\xampp\\htdocs\\nuevaviscaya\\includes\\runtime/../../layouts/v7\\modules\\Events\\partials\\Menubar.tpl',
      1 => 1602587794,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7544673125fd0504f6fc708-78569424',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5fd0504f74133',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5fd0504f74133')) {function content_5fd0504f74133($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate (vtemplate_path("partials/Menubar.tpl",'Calendar'), $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>