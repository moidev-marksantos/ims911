<?php /* Smarty version Smarty-3.1.7, created on 2021-01-21 01:43:22
         compiled from "C:\xampp\htdocs\nuevaviscaya\includes\runtime/../../layouts/v7\modules\Home\CovidTracker.tpl" */ ?>
<?php /*%%SmartyHeaderCode:4706981755fd2e950b29cb7-83481296%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '318a29ea1a295698d0a1f499c17e64a228833ea9' => 
    array (
      0 => 'C:\\xampp\\htdocs\\nuevaviscaya\\includes\\runtime/../../layouts/v7\\modules\\Home\\CovidTracker.tpl',
      1 => 1611193388,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4706981755fd2e950b29cb7-83481296',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5fd2e950b4b7a',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5fd2e950b4b7a')) {function content_5fd2e950b4b7a($_smarty_tpl) {?><div style="text-align: center;">

    <iframe frameborder="0" height="1200" width="915" marginheight="0" marginwidth="0" title="Data Visualization" allowtransparency="true" allowfullscreen="true" src="https://public.tableau.com/views/COVID-19CasesandDeathsinthePhilippines_15866705872710/Home?:embed=y&:showVizHome=no&:host_url=https%3A%2F%2Fpublic.tableau.com%2F&:embed_code_version=3&:tabs=no&:toolbar=yes&:animate_transition=yes&:display_static_image=no&:display_spinner=yes&:display_overlay=yes&:display_count=yes&publish=yes&:loadOrderID=0">
    </iframe>

</div><?php }} ?>