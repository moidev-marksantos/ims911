<?php /* Smarty version Smarty-3.1.7, created on 2020-12-09 02:56:05
         compiled from "C:\xampp\htdocs\nuevaviscaya\includes\runtime/../../layouts/v7\modules\Vtiger\ListViewQuickPreviewSectionHeader.tpl" */ ?>
<?php /*%%SmartyHeaderCode:17128081345fd03cc539dbc7-39933775%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '84ff86d3ef0c2849ea3323573678898951607dbe' => 
    array (
      0 => 'C:\\xampp\\htdocs\\nuevaviscaya\\includes\\runtime/../../layouts/v7\\modules\\Vtiger\\ListViewQuickPreviewSectionHeader.tpl',
      1 => 1602587794,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17128081345fd03cc539dbc7-39933775',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'TITLE' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5fd03cc539edf',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5fd03cc539edf')) {function content_5fd03cc539edf($_smarty_tpl) {?>


<div id="quickPreviewHeader">
    <div class="title"><?php echo $_smarty_tpl->tpl_vars['TITLE']->value;?>
</div>
</div><?php }} ?>