<?php /* Smarty version Smarty-3.1.7, created on 2020-12-09 01:03:34
         compiled from "C:\xampp\htdocs\nuevaviscaya\includes\runtime/../../layouts/v7\modules\ExtensionStore\Promotions.tpl" */ ?>
<?php /*%%SmartyHeaderCode:9449093315fd0201935a4f8-40135255%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b4bdeadc501704e2b32e2724cd55803822d0947f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\nuevaviscaya\\includes\\runtime/../../layouts/v7\\modules\\ExtensionStore\\Promotions.tpl',
      1 => 1607475811,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9449093315fd0201935a4f8-40135255',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5fd020193badf',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5fd020193badf')) {function content_5fd020193badf($_smarty_tpl) {?>


<?php }} ?>