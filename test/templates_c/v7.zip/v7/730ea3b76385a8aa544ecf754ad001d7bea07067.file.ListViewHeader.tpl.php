<?php /* Smarty version Smarty-3.1.7, created on 2020-12-09 03:18:51
         compiled from "C:\xampp\htdocs\nuevaviscaya\includes\runtime/../../layouts/v7\modules\Settings\Vtiger\ListViewHeader.tpl" */ ?>
<?php /*%%SmartyHeaderCode:7807503765fd0421b5018d1-76751786%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '730ea3b76385a8aa544ecf754ad001d7bea07067' => 
    array (
      0 => 'C:\\xampp\\htdocs\\nuevaviscaya\\includes\\runtime/../../layouts/v7\\modules\\Settings\\Vtiger\\ListViewHeader.tpl',
      1 => 1602587794,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7807503765fd0421b5018d1-76751786',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5fd0421b51f1f',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5fd0421b51f1f')) {function content_5fd0421b51f1f($_smarty_tpl) {?>

<div class="listViewPageDiv" id="listViewContent"><?php }} ?>