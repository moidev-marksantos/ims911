<?php /* Smarty version Smarty-3.1.7, created on 2020-12-09 05:02:13
         compiled from "C:\xampp\htdocs\nuevaviscaya\includes\runtime/../../layouts/v7\modules\Settings\Workflows\ListViewFooter.tpl" */ ?>
<?php /*%%SmartyHeaderCode:9969634185fd05a554be873-51604919%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a627da7e0b46b6506e3bc38292c26dd700a785f5' => 
    array (
      0 => 'C:\\xampp\\htdocs\\nuevaviscaya\\includes\\runtime/../../layouts/v7\\modules\\Settings\\Workflows\\ListViewFooter.tpl',
      1 => 1602587794,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9969634185fd05a554be873-51604919',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5fd05a554bfc5',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5fd05a554bfc5')) {function content_5fd05a554bfc5($_smarty_tpl) {?>

</div></div></div></div><?php }} ?>