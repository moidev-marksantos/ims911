<?php /* Smarty version Smarty-3.1.7, created on 2020-12-09 04:06:25
         compiled from "C:\xampp\htdocs\nuevaviscaya\includes\runtime/../../layouts/v7\modules\Settings\PickListDependency\ListViewFooter.tpl" */ ?>
<?php /*%%SmartyHeaderCode:11535329645fd04d4154ee86-71131897%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a46b74f6af67577d9af91c336ddade285020b527' => 
    array (
      0 => 'C:\\xampp\\htdocs\\nuevaviscaya\\includes\\runtime/../../layouts/v7\\modules\\Settings\\PickListDependency\\ListViewFooter.tpl',
      1 => 1602587794,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11535329645fd04d4154ee86-71131897',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5fd04d4154fdb',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5fd04d4154fdb')) {function content_5fd04d4154fdb($_smarty_tpl) {?>

</div></div></div></div><?php }} ?>