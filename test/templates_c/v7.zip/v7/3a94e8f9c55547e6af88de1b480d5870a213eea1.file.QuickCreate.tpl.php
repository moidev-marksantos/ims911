<?php /* Smarty version Smarty-3.1.7, created on 2020-12-09 03:11:26
         compiled from "C:\xampp\htdocs\nuevaviscaya\includes\runtime/../../layouts/v7\modules\Events\QuickCreate.tpl" */ ?>
<?php /*%%SmartyHeaderCode:11277392055fd0405e93b656-74402129%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3a94e8f9c55547e6af88de1b480d5870a213eea1' => 
    array (
      0 => 'C:\\xampp\\htdocs\\nuevaviscaya\\includes\\runtime/../../layouts/v7\\modules\\Events\\QuickCreate.tpl',
      1 => 1602587794,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11277392055fd0405e93b656-74402129',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5fd0405e95e2d',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5fd0405e95e2d')) {function content_5fd0405e95e2d($_smarty_tpl) {?>
    
<?php echo $_smarty_tpl->getSubTemplate (vtemplate_path("QuickCreate.tpl","Calendar"), $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>