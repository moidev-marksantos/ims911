<?php /* Smarty version Smarty-3.1.7, created on 2020-12-09 05:03:37
         compiled from "C:\xampp\htdocs\nuevaviscaya\includes\runtime/../../layouts/v7\modules\Settings\Workflows\LineItemsIndividualTemplate.tpl" */ ?>
<?php /*%%SmartyHeaderCode:7092537565fd05aa9b838e0-68995704%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '89d5c9a375a85b5ae4b660b2a6f8da27861f0231' => 
    array (
      0 => 'C:\\xampp\\htdocs\\nuevaviscaya\\includes\\runtime/../../layouts/v7\\modules\\Settings\\Workflows\\LineItemsIndividualTemplate.tpl',
      1 => 1602587794,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7092537565fd05aa9b838e0-68995704',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5fd05aa9b858b',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5fd05aa9b858b')) {function content_5fd05aa9b858b($_smarty_tpl) {?>



<DIV>TEMPLATE: layout/modules/Settings/Workflows/LineItemsIndividualTemplate.tpl</DIV>
<?php }} ?>