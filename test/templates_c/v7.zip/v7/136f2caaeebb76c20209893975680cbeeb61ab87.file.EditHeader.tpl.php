<?php /* Smarty version Smarty-3.1.7, created on 2020-12-09 05:02:16
         compiled from "C:\xampp\htdocs\nuevaviscaya\includes\runtime/../../layouts/v7\modules\Settings\Workflows\EditHeader.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2614844355fd05a58538826-90877705%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '136f2caaeebb76c20209893975680cbeeb61ab87' => 
    array (
      0 => 'C:\\xampp\\htdocs\\nuevaviscaya\\includes\\runtime/../../layouts/v7\\modules\\Settings\\Workflows\\EditHeader.tpl',
      1 => 1602587794,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2614844355fd05a58538826-90877705',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5fd05a5857b34',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5fd05a5857b34')) {function content_5fd05a5857b34($_smarty_tpl) {?>



<?php }} ?>