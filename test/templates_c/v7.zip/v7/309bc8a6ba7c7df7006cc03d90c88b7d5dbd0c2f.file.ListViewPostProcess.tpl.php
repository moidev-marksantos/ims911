<?php /* Smarty version Smarty-3.1.7, created on 2020-12-10 08:16:49
         compiled from "C:\xampp\htdocs\nuevaviscaya\includes\runtime/../../layouts/v7\modules\EmailTemplates\ListViewPostProcess.tpl" */ ?>
<?php /*%%SmartyHeaderCode:5391974055fd1d9710d47c4-05796126%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '309bc8a6ba7c7df7006cc03d90c88b7d5dbd0c2f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\nuevaviscaya\\includes\\runtime/../../layouts/v7\\modules\\EmailTemplates\\ListViewPostProcess.tpl',
      1 => 1607474557,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5391974055fd1d9710d47c4-05796126',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5fd1d9710d56a',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5fd1d9710d56a')) {function content_5fd1d9710d56a($_smarty_tpl) {?>
</div></div><?php }} ?>