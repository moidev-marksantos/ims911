<?php /* Smarty version Smarty-3.1.7, created on 2020-12-09 01:12:19
         compiled from "C:\xampp\htdocs\nuevaviscaya\includes\runtime/../../layouts/v7\modules\Settings\Vtiger\SettingsMenuEnd.tpl" */ ?>
<?php /*%%SmartyHeaderCode:17632148305fd02473a4a947-65010715%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'cfd16be11946d608ae7af26a04b3c60e6da4cdf8' => 
    array (
      0 => 'C:\\xampp\\htdocs\\nuevaviscaya\\includes\\runtime/../../layouts/v7\\modules\\Settings\\Vtiger\\SettingsMenuEnd.tpl',
      1 => 1602587794,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17632148305fd02473a4a947-65010715',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5fd02473a63cd',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5fd02473a63cd')) {function content_5fd02473a63cd($_smarty_tpl) {?>
</div></div><?php }} ?>