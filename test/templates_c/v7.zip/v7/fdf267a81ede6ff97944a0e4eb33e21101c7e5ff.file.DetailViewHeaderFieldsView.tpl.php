<?php /* Smarty version Smarty-3.1.7, created on 2021-01-22 06:40:23
         compiled from "C:\xampp\htdocs\nuevaviscaya\includes\runtime/../../layouts/v7\modules\Vtiger\DetailViewHeaderFieldsView.tpl" */ ?>
<?php /*%%SmartyHeaderCode:14058834515fd03939ed8766-95380356%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fdf267a81ede6ff97944a0e4eb33e21101c7e5ff' => 
    array (
      0 => 'C:\\xampp\\htdocs\\nuevaviscaya\\includes\\runtime/../../layouts/v7\\modules\\Vtiger\\DetailViewHeaderFieldsView.tpl',
      1 => 1611297622,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14058834515fd03939ed8766-95380356',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5fd03939ef385',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5fd03939ef385')) {function content_5fd03939ef385($_smarty_tpl) {?>

<?php }} ?>