<?php /* Smarty version Smarty-3.1.7, created on 2020-12-11 03:34:51
         compiled from "C:\xampp\htdocs\nuevaviscaya\includes\runtime/../../layouts/v7\modules\Home\Windy.tpl" */ ?>
<?php /*%%SmartyHeaderCode:16276048505fd2e605a82665-40689407%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '353aec3a2cbc40e5ab298e6184894f51f41d6780' => 
    array (
      0 => 'C:\\xampp\\htdocs\\nuevaviscaya\\includes\\runtime/../../layouts/v7\\modules\\Home\\Windy.tpl',
      1 => 1607657688,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16276048505fd2e605a82665-40689407',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5fd2e605a82d8',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5fd2e605a82d8')) {function content_5fd2e605a82d8($_smarty_tpl) {?><div style="text-align: center;">

    <iframe frameborder="0" height="1200" width="915" marginheight="0" marginwidth="0" title="Data Visualization" allowtransparency="true" allowfullscreen="true" src="https://public.tableau.com/views/COVID-19CasesandDeathsinthePhilippines_15866705872710/Home?:embed=y&:showVizHome=no&:host_url=https%3A%2F%2Fpublic.tableau.com%2F&:embed_code_version=3&:tabs=no&:toolbar=yes&:animate_transition=yes&:display_static_image=no&:display_spinner=yes&:display_overlay=yes&:display_count=yes&publish=yes&:loadOrderID=0">
    </iframe>

</div><?php }} ?>