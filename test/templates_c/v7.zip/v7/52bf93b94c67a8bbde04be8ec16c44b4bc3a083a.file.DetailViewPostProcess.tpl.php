<?php /* Smarty version Smarty-3.1.7, created on 2020-12-09 01:12:15
         compiled from "C:\xampp\htdocs\nuevaviscaya\includes\runtime/../../layouts/v7\modules\Vtiger\DetailViewPostProcess.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13121015125fd0246faa34f7-69077033%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '52bf93b94c67a8bbde04be8ec16c44b4bc3a083a' => 
    array (
      0 => 'C:\\xampp\\htdocs\\nuevaviscaya\\includes\\runtime/../../layouts/v7\\modules\\Vtiger\\DetailViewPostProcess.tpl',
      1 => 1602587794,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13121015125fd0246faa34f7-69077033',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5fd0246fab71a',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5fd0246fab71a')) {function content_5fd0246fab71a($_smarty_tpl) {?>



                </div>
            </div>
        </div>
    </div>
</div>
<?php }} ?>