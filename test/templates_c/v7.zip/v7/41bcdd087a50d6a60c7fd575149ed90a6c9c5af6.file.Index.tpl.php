<?php /* Smarty version Smarty-3.1.7, created on 2021-01-25 05:53:31
         compiled from "C:\xampp\htdocs\nuevaviscaya\includes\runtime/../../layouts/v7\modules\Home\Index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:355854284600e5cdb4930a5-48610683%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '41bcdd087a50d6a60c7fd575149ed90a6c9c5af6' => 
    array (
      0 => 'C:\\xampp\\htdocs\\nuevaviscaya\\includes\\runtime/../../layouts/v7\\modules\\Home\\Index.tpl',
      1 => 1607656929,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '355854284600e5cdb4930a5-48610683',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_600e5cdb4b2b1',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_600e5cdb4b2b1')) {function content_600e5cdb4b2b1($_smarty_tpl) {?>



<DIV>TEMPLATE: layout/modules/Home/Index.tpl</DIV>
<?php }} ?>