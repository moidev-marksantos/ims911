<?php /* Smarty version Smarty-3.1.7, created on 2020-12-09 01:05:29
         compiled from "C:\xampp\htdocs\nuevaviscaya\includes\runtime/../../layouts/v7\modules\Vtiger\ListViewPostProcess.tpl" */ ?>
<?php /*%%SmartyHeaderCode:958741935fd022d98c0ef9-42871363%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ba0b75951033f460196df2a2c6196ded1b216f36' => 
    array (
      0 => 'C:\\xampp\\htdocs\\nuevaviscaya\\includes\\runtime/../../layouts/v7\\modules\\Vtiger\\ListViewPostProcess.tpl',
      1 => 1602587794,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '958741935fd022d98c0ef9-42871363',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5fd022d98d5ff',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5fd022d98d5ff')) {function content_5fd022d98d5ff($_smarty_tpl) {?>
	</div>
</div>

<?php }} ?>