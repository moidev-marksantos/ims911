<?php /* Smarty version Smarty-3.1.7, created on 2020-12-09 01:23:57
         compiled from "C:\xampp\htdocs\nuevaviscaya\includes\runtime/../../layouts/v7\modules\Reports\ListViewPostProcess.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13444913605fd0272d41f9b7-69993734%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '225378d1a8802905207f221b7a787e5c86d302e0' => 
    array (
      0 => 'C:\\xampp\\htdocs\\nuevaviscaya\\includes\\runtime/../../layouts/v7\\modules\\Reports\\ListViewPostProcess.tpl',
      1 => 1602587794,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13444913605fd0272d41f9b7-69993734',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5fd0272d43290',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5fd0272d43290')) {function content_5fd0272d43290($_smarty_tpl) {?>
</div>
</div>
<?php }} ?>