<?php /* Smarty version Smarty-3.1.7, created on 2020-12-09 02:24:27
         compiled from "C:\xampp\htdocs\nuevaviscaya\includes\runtime/../../layouts/v7\modules\Users\ListViewFooter.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1912055415fd0355b0f7097-34492353%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'cc28d0aaac946a59de050412f266c03d2be3aa73' => 
    array (
      0 => 'C:\\xampp\\htdocs\\nuevaviscaya\\includes\\runtime/../../layouts/v7\\modules\\Users\\ListViewFooter.tpl',
      1 => 1602587794,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1912055415fd0355b0f7097-34492353',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5fd0355b11011',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5fd0355b11011')) {function content_5fd0355b11011($_smarty_tpl) {?>

</div></div></div></div><?php }} ?>