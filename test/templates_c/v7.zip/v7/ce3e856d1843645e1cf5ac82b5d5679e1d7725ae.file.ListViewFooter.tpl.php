<?php /* Smarty version Smarty-3.1.7, created on 2020-12-09 03:18:51
         compiled from "C:\xampp\htdocs\nuevaviscaya\includes\runtime/../../layouts/v7\modules\Settings\Vtiger\ListViewFooter.tpl" */ ?>
<?php /*%%SmartyHeaderCode:12429603435fd0421b7cace7-12681678%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ce3e856d1843645e1cf5ac82b5d5679e1d7725ae' => 
    array (
      0 => 'C:\\xampp\\htdocs\\nuevaviscaya\\includes\\runtime/../../layouts/v7\\modules\\Settings\\Vtiger\\ListViewFooter.tpl',
      1 => 1602587794,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12429603435fd0421b7cace7-12681678',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5fd0421b7cba1',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5fd0421b7cba1')) {function content_5fd0421b7cba1($_smarty_tpl) {?>

</div><?php }} ?>