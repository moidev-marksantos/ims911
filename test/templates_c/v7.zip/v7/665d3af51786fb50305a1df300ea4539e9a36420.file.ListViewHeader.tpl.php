<?php /* Smarty version Smarty-3.1.7, created on 2020-12-09 05:02:12
         compiled from "C:\xampp\htdocs\nuevaviscaya\includes\runtime/../../layouts/v7\modules\Settings\Workflows\ListViewHeader.tpl" */ ?>
<?php /*%%SmartyHeaderCode:11896531005fd05a54d38b49-27954412%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '665d3af51786fb50305a1df300ea4539e9a36420' => 
    array (
      0 => 'C:\\xampp\\htdocs\\nuevaviscaya\\includes\\runtime/../../layouts/v7\\modules\\Settings\\Workflows\\ListViewHeader.tpl',
      1 => 1602587794,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11896531005fd05a54d38b49-27954412',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5fd05a54d9511',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5fd05a54d9511')) {function content_5fd05a54d9511($_smarty_tpl) {?>

<div class="listViewPageDiv" id="listViewContent"><div class="col-sm-12 col-xs-12 "><div id="listview-actions" class="listview-actions-container"><div class="list-content row workflowListContainer" id="list-content">
<?php }} ?>